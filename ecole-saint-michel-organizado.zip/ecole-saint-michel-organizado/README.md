# École Saint-Michel LMS

Proyecto organizado en HTML, CSS y JavaScript.

## Archivos principales

- index.html: dashboard maestro/admin
- login.html: inicio de sesión demo
- estudiante.html: portal del estudiante
- alumnos.html: administración de alumnos con Supabase
- lecciones.html: biblioteca de lecciones
- voz-frances.html: práctica de pronunciación en francés

## Carpetas

- assets/img/: logo e imágenes
- assets/audio/frances/: audios MP3 de francés
- css/: estilos separados por página
- js/: funciones separadas por módulo
- data/: datos de lecciones o vocabulario

## Importante

Para usar reconocimiento de voz en iPhone o Android, súbelo a GitHub Pages con HTTPS.
